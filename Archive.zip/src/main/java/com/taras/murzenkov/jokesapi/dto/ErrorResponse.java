package com.taras.murzenkov.jokesapi.dto;

public record ErrorResponse(String message) {
}
