# What is missing

API client

Caching
Retrying

Application
Tests

CI/CD